---
novel_os_schema: "novel-classification.v1"
novel_os_catalog: "novel-types.2026-09"
classification_id: "classification:bd43feda2388f614dfa45f3ffb584245f384cc5bad03f5e45d4d7dc5474e468f"
primary_genre_id: "general_fiction"
secondary_genre_ids: []
story_type_ids: ["domestic_betrayal"]
tone_ids: ["suspenseful"]
setting_ids: ["family_domestic"]
filter_type_ids: ["general_fiction", "domestic_betrayal", "suspenseful", "family_domestic"]
audience_channel: "general"
audience_age_band: "unknown"
length_form: "short"
chapter_band: "chapters_0_50"
serialization_schema: "novel-serialization.v1"
serialization_id: "serialization:deec2dc9436dc8981a5361905cc7ecfa38c999f654074504060bea231130fcb4"
narrative_format_id: "narrative-format:7ba34d0212370898836afd602bc6aa9d3c29312378ba8135e3aaaa122a72310c"
narrative_mode: "short_novel"
total_chapters: 21
volume_count: 1
series_id: ""
---

# He Chose His Hidden Family for Twenty Years and Abandoned Our Daughter During Her Most Important Life Events.

*Terry · Adult Contemporary Family Suspense*

## Introduction

## A Marriage Measured in Receipts

*Can Eleanor prove her husband built a hidden family with the money—and home—he claimed to protect?*

When Eleanor Vance discovers that Richard skipped their daughter Chloe’s graduation to celebrate with a family he has concealed for years, betrayal becomes a fight for survival. Richard controls the finances, dismisses Eleanor’s decades of unpaid labor, and threatens the house whenever she challenges him. Then an unknown lender reveals an eighty-thousand-dollar debt bearing a signature Eleanor did not write.

With Chloe beside her, Eleanor resists the urge to retaliate and begins assembling a case: a Fort Wayne video, toll records, debit cards, tuition payments, expense claims, and the old ledgers that preserve everything Richard expected her to forget. Each document promises a precise reversal—his practiced stories tested against institutional proof, and Eleanor’s invisible sacrifices reclaimed as evidence of her rightful stake. Chloe faces a parallel reckoning as she sets boundaries with the father whose money has always stood in for presence, while building a nursing future no longer dependent on his praise.

But Richard still has access, authority, and time to reshape the story. Before he moves the assets or turns the law against her, can Eleanor make the paper trail speak loudly enough to save her home and choose a life beyond him?

## The Reserved Seat and the Speech

The chair beside Mom bore Richard’s name. It had been empty long enough for the paper card to curl at one corner.

Chloe Vance paused in the aisle, fingers tightening around her program. The auditorium smelled of floor polish, warm dust, and lilies arranged beneath the stage. Beyond the rows of black gowns, doors opened and closed as late families hurried in. Each time, she looked up.

Not him.

Eleanor patted the seat beside her. “Come on, honey. You’re going to wrinkle your robe.”

Chloe sat and smoothed the blue honor cord across her chest. “He’ll make it.”

Her phone buzzed against her thigh.

Running into an emergency equipment failure in Cleveland. I’m sorry. Proud of you. Congratulations.

That was all. No hospital name. No estimate. No call.

She read it twice, then locked the screen before Eleanor could glance over. The message lodged beneath her ribs, a small, hard weight.

“Your father?” Eleanor asked.

“Equipment trouble,” Chloe said. “In Cleveland. He’s trying to handle it.”

Eleanor’s mouth tightened, but she nodded. “Of course he is.”

The orchestra began. Chloe tucked the phone beneath her program and fixed her gaze on the stage. She could be proud for one afternoon. She could keep the pieces together through the photographs, the drive home, the moment Richard walked through the door with a story that made everything make sense.

When her name appeared on the screen above the podium, applause rose around her.

Chloe stood. Her heels clicked across the polished floor. The microphone smelled faintly of metal when she leaned toward it.

“Every patient remembers whether we were present,” she began.

The room quieted.

“They remember the nurse who checked the monitor twice. The one who explained the next medication instead of rushing away. The one who stayed when fear made the room feel too small.”

Her gaze moved over caps and faces, over professors in dark robes, over Eleanor’s raised phone. She kept the empty chair at the edge of her vision, a pale square beside her mother.

“Vigilance is more than noticing a change in vital signs. It means recognizing the person attached to them. Trust is built in small decisions, especially when someone is vulnerable and has no choice but to depend on us.”

Her voice held. Heat gathered in her cheeks, but she did not look down.

“So we show up. We listen. We return when we say we will. That is the promise of this profession.”

For one breath, the silence belonged to her. Then the auditorium broke open.

Eleanor’s phone remained raised, its red recording light steady. Chloe heard clapping, whistles, the scrape of chairs as people stood. Faculty members embraced her near the stage. Someone placed her diploma in her hands.

Eleanor gave her the card and pen Chloe had bought with her first clinical paycheck. Gold lettering caught the light. Chloe smiled for the camera, diploma against her ribs, pen tucked beside it.

In every photograph, Richard’s chair remained visible.

Empty.

“Beautiful,” Eleanor said softly.

Chloe kept smiling. “He would have been here if he could.”

Outside, sunlight flashed across the parking lot. Eleanor unlocked the car, and Chloe climbed into the passenger seat with flowers, diploma, and the recording that preserved the vacant place beside her.

As the auditorium receded in the side mirror, Chloe prepared to explain why Richard’s Cleveland emergency had to be real, even as the image of his empty chair said otherwise.

## The Thirst for a Glance

Richard’s text glowed in Chloe’s lap as the car carried them away from campus.

I’m sorry, sweetheart. Equipment failure at the Cleveland hospital. Couldn’t leave. Proud of you. We’ll celebrate soon.

The words had begun to blur, but she read them again. The phone warmed her palm. Beneath it, her graduation gown scratched her knees, a cheap blue seam against skin still marked by the cap’s tight elastic.

“He tried to come,” Chloe said.

Eleanor kept both hands on the wheel. “I know.”

“The equipment failure must have been serious. Hospitals can’t wait because someone has a ceremony.”

“No,” Eleanor said. “They can’t.”

Storefronts and traffic lights slid across the windows. Chloe pressed her thumb over Richard’s name, as if she could hold the message in place. He had sent money for her pinning ceremony, paid the apartment deposit, called before dawn on exam days to tell her she was brilliant.

“He’s proud of me,” she said.

Eleanor glanced at her, then returned her eyes to the road. “You know he is.”

The answer should have settled something. Instead, it opened a hollow place beneath Chloe’s ribs.

At home, Eleanor had set the dining room table for three. Good plates waited beneath folded napkins. A roast cooled in its pan, filling the house with rosemary, browned butter, and the faint metallic smell of the dishwasher. Richard had given them no arrival time. His last message said only, Later.

Chloe checked her phone before removing her shoes.

“He might still make it.”

“He might.”

Eleanor carried the roast to the table. The extra plate shone beneath the chandelier, too bright for an empty place. Chloe pulled out her chair and sat where she had since childhood, facing it.

“Remember my spelling bee?” Eleanor asked.

Chloe laughed softly. “He was in surgery.”

“He said he was stuck in traffic.”

“Traffic from the hospital. It was snowing.”

“He came after they took down the banners.”

“He came,” Chloe said. “That counts.”

Eleanor set the serving spoon beside the roast. “And when you broke your leg?”

“He was traveling for work. He drove all night to get back.”

“He arrived the next afternoon.”

“Because the roads were bad.”

The excuses came easily now. Too easily.

Eleanor sat across from her. “Your eighteenth birthday?”

Chloe tightened her grip on the phone. “He had a conference.”

“He forgot until I reminded him.”

“He sent flowers.”

“Two days late.”

“They were beautiful.”

Silence thickened between them, carrying the smell of gravy and the clock’s steady ticking.

Chloe reached into her purse for the old keychain. The metal hospital logo had worn smooth beneath years of her fingers. Richard had given it to her at seven, after bringing her to his office for an hour between meetings. She had kept it ever since.

“And this,” she said, touching the bear pendant at her throat. “He bought it at the airport when I had pneumonia. He said the bear was brave because it kept standing after winter.”

Eleanor’s gaze dropped to the pendant. “Those things matter to you.”

“They prove he thinks about me.”

“Money proves he provides.”

“He does more than that.”

“Does he show up?”

Heat climbed Chloe’s face. “He loves me in his own way.”

The sentence landed with the dull familiarity of a prayer.

“He loves me in his own way,” Chloe repeated. “The hospital needed him. The spelling bee was traffic. My leg was the roads. My birthday was the conference. He always has a reason because his work matters.”

Eleanor didn’t argue. That frightened Chloe more than anger would have.

The phone stayed silent. The roast darkened at the edges. Across the table, her mother looked at the keychain, the pendant, the untouched plate.

Chloe curled her fingers around both objects.

“He’ll come,” she said.

Eleanor’s expression shifted, almost imperceptibly. Not disbelief. Recognition.

Chloe knew she hadn’t convinced her mother. She had only repeated the script, every line polished by years of practice, every excuse worn smooth enough to pass for faith.

## The Video from Fort Wayne

The link arrived beneath a photograph of Chloe in her blue gown.

Mara Singh had forwarded it with one sentence: *Thought this might be yours.*

Chloe stood at the kitchen counter, her phone trembling in her hand. The refrigerator hummed behind Eleanor. Beyond the window, a lawn mower coughed, then stopped.

“Mom,” Chloe said. “You need to watch this.”

Eleanor dried her hands on a dish towel and took the phone. The video opened on a backyard strung with gold balloons. A cardboard twenty hung above a table crowded with bottles, paper plates, and a cake glazed in blue icing.

Then Richard stepped into the frame.

For one second, Eleanor reached for the explanation he had given her that morning, repeating it until exhaustion had made it sound rehearsed.

*Cleveland. Hospital equipment failure. No way around it. I’m sorry I’ll miss the speech.*

The timestamp sat beneath the video: 7:42 p.m., Saturday.

Chloe’s honors speech had begun at 7:30 in the auditorium. Eleanor remembered the exact minute because she had taken a photograph when Chloe walked to the podium. Seven forty-two. She had held her breath while Chloe thanked the teachers who stayed late, the friends who carried one another through exams, the family who taught her to keep going.

Richard had been in Fort Wayne.

Eleanor enlarged the location tag.

FORT WAYNE, INDIANA.

The phone seemed to gain weight in her hand. Cold dishwater ran over her fingers and darkened the towel.

“Maybe it was an old video,” Chloe whispered.

“Mara got it from the graduation parent group today.”

“That doesn’t mean he uploaded it today.”

“No.” Eleanor tapped the timestamp. “But the recording was made then.”

The camera swung toward a young man in a white shirt. Leo Foster grinned beneath a paper crown while guests shouted his name. Julianne Foster stood beside him, one hand on his shoulder, the other curled around a champagne flute.

Richard moved through them as if he belonged there.

He kissed Julianne’s cheek. She leaned into him without hesitation. Leo called, “Dad,” and Richard turned with a laugh that opened his whole face.

Eleanor had spent twenty years collecting smaller versions of that laugh, saving them for birthdays, anniversaries, the rare Sunday when he came home before dark. On the screen, he gave it away freely.

A guest placed a ring of keys in Richard’s palm. He lifted them, metal flashing beneath the party lights.

“For the birthday boy,” he said.

Leo stared. “You’re kidding.”

“Pickup’s yours.”

The yard erupted. Leo seized Richard in a hug. Someone shouted that he had the best father in the world.

Eleanor fixed on the keys. A pickup truck. Insurance. Registration. Payments. The electric bill she had postponed. The vacation fund they had emptied when Richard said the furnace might fail. Numbers surfaced, sharp and uninvited, then disappeared beneath Chloe’s breathing.

“Mom, call him.”

Chloe reached for her phone. Eleanor caught her wrist.

“Not yet.”

“He lied.”

“I know.”

“Then why are you stopping me?”

Because anger could scatter everything. Richard could claim the video was altered, misdated, misunderstood. Once he knew they had it, the link might disappear, taking the first solid piece of truth with it.

Eleanor took screenshots: the timestamp, the location tag, Richard’s face, Julianne’s hand on Leo’s shoulder, the keys above the cake. She copied the URL into a document and recorded Mara’s name, the graduation group, the visible guests - every detail she could anchor to a date.

Then she saved the files to two drives.

Chloe watched in silence. On the phone, Richard laughed again, his arm around Leo. The sound crossed the glass and lodged between them.

“Why does he look happier with Leo than he ever looks with me?” Chloe asked.

Eleanor had no answer that could preserve the marriage’s respectable surface.

Chloe lowered her phone. Her defense of him, worn thin through years of wanting, finally gave way.

Outside, a car rolled past their house and kept going.

Richard was still in Fort Wayne, fixed in evidence, smiling at the family he had never admitted existed.

## The Blueprint of His Success

The box waited beneath the winter blankets, cold as a held breath.

Eleanor knelt at the back of the closet and drew out the dented metal case she had not opened in twenty-five years. Dust silvered the latch. Her fingers hovered before they touched it.

After the video, she had promised Chloe she would sleep. Instead, she listened to the house settling around them, each creak a question. Richard in Fort Wayne remained fixed behind her eyes: his smile, his hand on a little boy’s shoulder, the date stamped in the corner.

She had kept the box because some part of her knew the story was being erased.

The latch snapped.

Inside, the papers lay in the order she had imposed long ago: resignation letter, business notes, ledgers tied with fading blue ribbon, pawn slips folded into an envelope, the directors’ contact book softened at the corners by her hands.

Her resignation letter bore her old name in a slanted, careful hand.

Dear Mr. Haskins,

I am writing to resign my position effective June 3.

The words had sounded dignified then. Necessary. Richard’s travel schedule had doubled. Clients wanted dinners, airport pickups, follow-up calls. Someone had to keep the house running, the children fed, the bills paid. Richard had called it temporary - six months, perhaps a year. He had kissed her forehead and promised they would be partners in his success.

She turned the page.

In the margin of a business notebook, she had written:

Cleveland Tuesday. Indianapolis Thursday. Send revised bid. Confirm hotel. Call Mrs. Leland about Richard’s presentation.

Her handwriting filled three pages before the first coffee stain.

She had arranged flights, typed proposals, found replacement tires, mailed invoices, remembered birthdays that softened difficult clients. She had learned which wives answered the phone and which secretaries held grudges. Richard called himself self-made because no one had watched her build the scaffolding.

The pawn slips came next.

Gold chain, one hundred eighty dollars.

Mother’s ring, three hundred.

Diamond studs, balance due.

Eleanor pressed the slips flat. Shame rose, hot and familiar. She had called the jewelry only metal, told herself the money would return when Richard’s commissions settled. Instead, each sacrifice had vanished into groceries, insurance premiums, hotel deposits - the small emergencies that kept his momentum from breaking.

Concrete. Traceable. Missing from every story he told.

She spread the ledgers across the desk. Dates, phone numbers, names, household expenses. Her columns tracked school fees beside client lunches, mortgage payments beside conference registrations. The work had never been invisible. She had simply been the only person required to forget it.

A floorboard creaked in the hall.

“Mom?”

Chloe’s voice carried through the door, careful and raw.

Eleanor covered the pawn slips with a ledger. “I’m here.”

“Are you coming to bed?”

“In a minute.”

Silence lingered, then retreated. Eleanor pictured Chloe outside, deciding whether to knock. She wanted to call her in, place every page in her daughter’s hands, and say, Look. I was here. I held this family together.

Instead, she reached for her phone and photographed each document - front and back, close enough to read every date. She created a folder named ARCHIVE, then arranged the originals chronologically.

The contact book resisted opening. Its pages smelled of mildew and old perfume. Near the middle, beneath a list of Cleveland directors, a name stopped her.

Lutheran Hospital, Fort Wayne.

Beside it was a date Richard had sworn belonged to a Cleveland equipment trip.

Eleanor read the entry twice, then photographed it.

She closed the book, but the date stayed bright. The video had not been an isolated betrayal. It had a paper trail.

She returned every original to the box, locked it, and slid it beneath the blankets. Tomorrow, she would show Chloe the records. Not all at once. Enough to begin.

The respectable story of their marriage had protected Richard.

Now Eleanor would let the documents speak.

## The Secret Debit Cards

The first debit card landed on the kitchen table with a soft plastic slap.

I flinched anyway.

Eleanor placed three more beside it, all black, none bearing a name. Loose receipts whispered across the wood beneath her careful hands. The kitchen smelled of lemon cleaner and coffee gone cold. Outside, a truck groaned through the neighborhood, then faded.

“Where did you get these?”

“From the metal box.”

My fingers hovered over the nearest card. Its last four numbers matched a receipt from a Fort Wayne fuel station. Another card carried the same pattern - another station, another month.

“Call him,” I said.

Eleanor’s mouth tightened. “Call Richard and say what?”

“That I know.”

“You know he was in Fort Wayne once. You know a video exists. This is more, but it isn’t proof of who held these accounts.”

The word proof scraped against me. I wanted Richard’s voice in my ear, the pause before his explanation, the smooth concern he used whenever my questions came too close. I wanted to ask why Cleveland had so many Fort Wayne exits.

Instead, I pulled a receipt toward me.

The header belonged to a boarding program. Leo Foster’s name appeared beneath a student identification number, followed by a tuition installment large enough to close my throat. Three months later came another payment, then another. The dates marched across the paper in obedient black type.

Eleanor sorted beside me. Tuition. Truck financing. Fuel. Hotels. Meals. Toll statements folded into neat squares.

“This isn’t a birthday gift.”

“No.”

“It’s a life.”

Her hand stopped over a hotel receipt. “A second household.”

The phrase settled between us. I pictured Leo in the Fort Wayne video, cap backward, laughing beside Julianne while Richard stood close enough to touch them both. The timestamp had made the betrayal undeniable. These papers gave it weight, a monthly pulse.

I spread the toll statements in a row. Richard’s Cleveland hospital-equipment trips appeared in his old calendar, dates I remembered because he had called from hotel rooms and complained about conference coffee. The toll records placed his vehicle heading toward Fort Wayne on several of those same days.

“Look.”

Eleanor leaned over the table. Her perfume carried a faint cedar scent, the same scent trapped in the metal box.

“Could be another vehicle,” she said. “Someone using the card.”

“Then why do the dates line up?”

“They line up. That’s what we write down. Not what we assume.”

My phone lay beside the receipts. Richard’s name waited in the contacts list, familiar as a bruise. I opened a message.

I know about Fort Wayne. I know what you paid for Leo.

The words looked too small for the years behind them. My thumb hovered over Send.

Eleanor covered the phone with her palm. “Confront him now and he can deny it, destroy whatever remains, or turn this into your anger against him. Let him believe we have nothing concrete.”

“He already believes that.”

“Good.”

She photographed each card, receipt, and toll statement, marking the images with dates and source numbers. Originals went into a clear envelope; copies went into a separate folder.

I opened a blank document and built a chronology: payment, location, claimed business trip, toll route, supporting record. My hands steadied as the lines accumulated. This was no longer a daughter begging her father to explain himself. It was a record.

Then I found the receipt.

The date sat in the corner, ordinary and sharp. That same week, I had signed for extra student loans, borrowing more so the household bills wouldn’t crush him.

The receipt showed Leo’s truck down payment.

Richard had been paying for Leo while I borrowed money to spare him.

I saved the file. The message to Richard remained unsent.

## The Late Entrance

At 11:47, the front lock turned.

Chloe sat at the dining table with her diploma folder beneath both hands. The house had been waiting since dinner. Eleanor’s plate remained covered on the counter. The roast had gone cold. Even the balloons tied to the staircase sagged toward the floor.

The door opened, and Richard brought the outside in with him: whiskey, charcoal smoke, sweet barbecue, the sour heat of an afternoon spent somewhere else.

He kicked off one shoe, missed the mat, and left the other on.

“Richard.” Eleanor’s voice came from the kitchen. “Do you know what time it is?”

He loosened his tie without looking at either of them. “Cleveland ran late.”

The explanation arrived polished and ready. Equipment failure at the hospital. An emergency delivery. No way to leave until the thing was operating. Chloe had heard versions for years, each built to make his absence sound expensive and noble.

She rose with the folder.

“Dad.”

He turned halfway. His eyes touched her face, then dropped to the blue cover in her hands. “What’s that?”

“My diploma.”

She held it toward him. Gold lettering caught the lamplight: Bachelor of Science, her name beneath it. She had imagined this moment so often that the imagined version had acquired weight. His hand on her shoulder. A surprised laugh. Maybe, if she was lucky, pride breaking through his reserve.

Richard took the folder by one corner and shoved it onto the sideboard. It struck a porcelain bowl and slid beneath the mail.

“Ask your mother if there’s soup,” he said. “Or aspirin. My head’s splitting.”

For a second, Chloe nearly supplied the defense. He’s tired. He drove from Cleveland. He would have come if he could.

Then she noticed what he hadn’t asked.

Where was the ceremony? What had she spoken about? Who had sat beside her? Not one question. Not even, How did it go?

Eleanor stepped into the dining room, wiping her hands on a dish towel. “You said you’d be home before the reception ended.”

“I said the job would determine when I got home.”

“You smell like a bar.”

“I smell like a man who worked.”

“Worked until nearly midnight?”

Richard’s mouth tightened. Fatigue moved over him like a costume he could pull on whenever anyone challenged him. He pressed two fingers to his temple and sighed toward the ceiling.

“This is unbelievable. I miss one event, and suddenly I’m on trial.”

“One event?” Eleanor asked. “You missed her graduation.”

“I told you, Cleveland - ”

“Cleveland didn’t make you ignore her just now.”

His gaze snapped to Chloe. “Don’t start.”

The bear pendant rested against her throat, warm from her skin. Her fingers closed around it beneath her collar.

She kept her voice small. “Did you know the ceremony had already begun when you decided to stay?”

Richard reached for his briefcase near the door. “I’m not answering an interrogation in my own house.”

“It was a question.”

“It was disrespectful.”

He carried the briefcase down the hall, each step deliberate, as if the walls belonged to him more than the people inside them. At the bedroom door, he looked back.

“Keep the lights down. I need privacy.”

Then he shut the door.

The diploma folder waited beneath the mail. Chloe retrieved it without opening it. The cardboard smelled faintly of the bookstore and auditorium dust. She carried it upstairs, past the unchanged locks, past framed photographs of Richard smiling at occasions he had attended.

In her room, she opened her notebook.

11:47 p.m. Returned smelling of alcohol, charcoal, barbecue. Repeated Cleveland equipment failure. Asked for soup or aspirin. Did not ask about ceremony. Called question disrespectful. Refused discussion.

She paused, pen hovering.

The receipts and toll records lay hidden in Eleanor’s desk downstairs. Chloe could have brought them out, forced him to study the dates, made him defend the miles between Cleveland and every other place.

Instead, she closed the notebook.

Richard hadn’t asked where the ceremony was held.

His absence wasn’t an accident waiting to be forgiven. It was a place he had never intended to be.

## The Unmasked Hypocrite

The first thing Richard saw was his own face, fixed above the date.

Eleanor had arranged the papers across the kitchen table in a line from left to right, past to present. Graduation stills. The Fort Wayne timestamp beneath them. Toll bills, each destination circled in blue. Anonymous debit statements stacked by month, their totals leading back to the same addresses.

Chloe stood beside the sink, her arms folded tight. She had brought the records into the house. Eleanor had given them order.

Richard dropped his keys into the bowl. Metal struck ceramic. “What is this?”

“Sit down.”

His mouth tightened. “I’ve had a long day.”

“So have we.”

He looked to Chloe first, searching for the weak seam - the daughter who used to apologize before he finished speaking. She kept her eyes on the table.

Eleanor touched the first still. Chloe in her blue graduation gown, one hand raised toward the camera. Behind her, the auditorium doors. In the corner of the frame, a timestamp.

“May eighteenth,” Eleanor said. “Two fourteen in the afternoon. You told us you were in Fort Wayne for the equipment demonstration.”

“I was.”

“The video places you there during Chloe’s graduation.”

“I said I was in Fort Wayne.”

“During her graduation.”

Richard pulled out a chair but didn’t sit. “You went through my things.”

“Here is the toll charge from two forty-three that afternoon. Fort Wayne to South Bend. Here is the return charge the next morning.”

“That proves I drove somewhere for work.”

Eleanor slid the statements toward him. Paper rasped against paper. “Then why do the debit payments repeat at the same grocery store, pharmacy, and school-supply shop?”

His tired mask held for another second. Then it slipped. Color climbed his throat.

“You had no right to access those accounts.”

“We’re discussing dates.”

“You invaded my privacy.”

“May eighteenth. June third. July ninth.” Eleanor kept her voice level. Her phone rested beneath the edge of a folded dish towel, recording the scrape of his chair, the change in his breathing. “Each trip begins near Fort Wayne. Each payment appears in Julianne Foster’s neighborhood.”

Richard flattened his hand on the table. “Do not bring her into this.”

The room narrowed around that sentence. Chloe inhaled, quick and small.

“You said the travel was business. You said the expenses were reimbursed. Are these payments yours?”

“I helped someone. That’s all.”

“Who?”

“None of your concern.”

“Then why conceal it?”

His gaze snapped toward the phone, though the towel hid it. “Who accessed those accounts?”

Eleanor turned another page. “I’m asking about the card ending in 4417.”

Richard went still.

She began to read the number aloud. “Four four one seven, nine two - ”

“Julianne uses that card,” he said.

The words escaped before he could catch them.

Chloe’s hand rose to her mouth. Richard stared at the statements as if the table had opened beneath him.

Eleanor stopped recording only long enough to secure the file. “You recognized it.”

“I know nothing about your little investigation.”

“You identified the account before I finished.”

“Give me every copy.” His voice cracked into anger. “Now. Whoever searched those records, tell me who it was.”

“No.”

His chair struck the wall. “You think this is a game? Searching marital records has consequences.”

The threat settled between them, heavier than the papers.

Eleanor gathered the statements, stills, and toll bills. Her hands stayed steady. She slipped the phone into her pocket and carried the evidence toward the locked drawer in the hall.

Richard watched her go.

For the first time, she didn’t turn back to soften the blow.

## Cruel Admissions

The phone lay beneath the folded tablecloth, its red recording light hidden in shadow.

Eleanor kept her hands flat beside the evidence. The graduation video played without sound, frozen on Chloe beneath the Fort Wayne banner. Beside it sat the timestamp, toll records, anonymous debit cards, and receipts arranged in a clean row.

Richard leaned over them. “That card number is mine.”

His finger hovered above the plastic.

“You said you never used it in Fort Wayne.”

“I said I didn’t go there for what you’re implying.”

“You recognized the number before I told you where it appeared.”

His mouth tightened. Behind him, Chloe stood with both hands around the bear pendant at her throat. The chain trembled against her skin.

Richard snatched up the toll sheet. “This route is a coincidence. I had equipment meetings.”

“On the same nights Leo had games?”

“That’s my job.”

“Your job paid for hotels, dinners, gas, and another household.”

He laughed once, without humor. “You want to turn a marriage into a ledger?”

“I made the ledger because you made the marriage one.”

The words settled between them. Beneath the tablecloth, the phone clicked on, capturing every breath.

Richard turned on her. “You resigned. You pawned your jewelry. You stayed home and decided to play martyr. Nobody forced you.”

Her ring finger ached where her wedding band had rubbed the skin thin.

“I kept this house running.”

“You chose that.”

“I paid your licensing fees.”

“You chose that too.”

“I raised Chloe while you built your career.”

His eyes flicked toward their daughter. “And she got a roof, tuition, a car. Don’t pretend she got nothing.”

Chloe’s face emptied.

Richard gathered the receipts into a crooked stack. “Every request, every emergency, every milestone. She treats me like an account that owes her a return.”

“Stop,” Chloe whispered.

“Leo never does this. Leo understands what a father provides. He appreciates it. Julianne understands it too.”

Something inside Eleanor went quiet. Not broken. Finished.

Richard picked up his phone. “I’m calling Julianne.”

“You don’t have to.”

He pressed the speaker button anyway.

Julianne answered on the fourth ring. “Richard?”

“Tell them,” he said. “Tell Eleanor what you know about sacrifice. About how a man should be allowed to spend his money where it matters.”

Silence breathed through the speaker.

Richard’s voice sharpened. “I provide for you and Leo. I don’t get interrogated for every dollar. Eleanor thinks keeping house makes her my partner in everything.”

“Richard,” Julianne said softly.

“And Chloe thinks being my daughter means unlimited withdrawals.”

Chloe flinched as if he had struck her.

Julianne said nothing. The silence lengthened until Richard’s certainty began to sound like pleading.

Eleanor watched his face change. He needed Julianne to confirm the hierarchy, to make cruelty respectable. Instead, only the faint hum of her breathing came through the phone.

“You hear me?” he demanded.

“I hear you,” Julianne answered.

No defense. No agreement.

Richard ended the call.

Then he bent close to Eleanor. His cologne carried cedar and old sweat. “You think these papers protect you? This house is secure because I made it secure. If I stop paying, you may find out how little of it belongs to you.”

Eleanor kept her expression still. “Is that a threat?”

“It’s a fact.”

The phone recorded every word. She let him believe the table held everything.

That night, after Richard shut himself in the study, Eleanor copied the recording to a second device and sealed it beneath the winter linens. She replayed his voice once.

Deliberate. Precise. No confusion. No shame.

Choice.

Across the room, Chloe touched the bear pendant. “Did he ever love me?”

Eleanor had no answer left that would protect either of them.

From the study came the scrape of a drawer opening.

Then Richard called, “Eleanor? We need to discuss what happens to this house.”

## The Broken Trinket

The question had lived beneath her tongue so long it tasted like blood.

Richard stood near the mantel, one hand braced against the wood, as if the house belonged to him by weight alone. Eleanor remained beside the sofa, pale and silent. Dust, old coffee, and the sharp wool of Richard’s coat thickened the room. Chloe curled her fingers around the bear pendant at her throat. Its metal body had warmed against her skin.

“Did you ever love me?”

Richard’s mouth tightened. “What kind of question is that?”

“The kind you answer.”

“I’ve answered plenty tonight.” He glanced at Eleanor, inviting an audience, then turned back to Chloe. “I paid your tuition. Your apartment. The car you drove through nursing school. Every Christmas, every emergency, every time you decided you needed something.”

“That isn’t what I asked.”

“It’s exactly what you asked, dressed up in sentiment.” His voice stayed level, almost bored. “You had a roof. Food. Opportunities your mother and I never had. I gave you everything.”

“Everything you could put on a receipt.”

The words scraped out before she could soften them. Richard’s eyes narrowed.

“You think affection pays bills?”

“I think a father can do both.”

Eleanor shifted, her sleeve brushing the sofa. Chloe didn’t look at her. If Eleanor spoke, Richard would turn this into another trial, another ledger with Chloe listed under expenses and grievances.

Chloe tightened her grip on the pendant. The chain bit into her palm.

“When I was six,” she said, “you took me to the fair after my stitches came out. I was afraid of the rides. You bought me this.” She lifted the bear between them. “You said it was brave because it kept standing after it fell.”

Richard stared at the pendant as if she had set a dead insect on his desk.

“Do you remember?”

“I remember wasting money on cheap toys.”

“It wasn’t cheap to me.”

“That’s your problem.” He pushed away from the mantel. “You make symbols out of ordinary things, then punish everyone when they don’t worship them with you.”

Her throat closed. She had wanted one memory. One honest sentence. Yes, I loved you then. Yes, I love you now. Even a careful lie might have given her somewhere to stand.

“Just tell me,” she whispered. “Was there ever a time you wanted me, not what I could become? Not what I cost?”

Richard laughed once, without humor. “You are unbelievable. After everything I’ve done, you stand there demanding proof.”

“I’m asking if I mattered.”

“You mattered enough for me to provide.”

He reached for the pendant. Chloe should have stepped back. Instead, she held still, waiting for him to touch the bear gently, to recognize the years she had carried it.

Richard flicked it from her fingers.

The pendant struck the coffee table, then dropped to the floor. The chain snapped with a tiny metallic pop. One ear of the bear broke loose from its loop. The pieces skittered beneath the lamplight, harmless and final.

Eleanor took one step forward.

“Don’t,” Chloe said.

Richard spread his hands. “Look at that. A tantrum over a trinket.”

Chloe lowered herself to her knees. The bear lay inches away, its scratched face turned toward the ceiling. She could reach it. Gather the chain. Find a jeweler. Preserve the proof. She had repaired worse things for less reason.

Richard waited.

That was the shape of it. He would stand there until she pleaded, until she made the broken object mean something for both of them, until he could call her grateful for accepting scraps.

Chloe rose without touching the pieces.

Eleanor’s eyes shone, but she did not reach for her. She moved aside, leaving the doorway clear.

Behind Chloe, Richard exhaled through his nose. “You’ll come back when you’re ready to be reasonable.”

Chloe stepped into the hall.

The pendant remained on the floor between them, broken and visible. For once, she did not bend to make the room comfortable.

## Eviction from the Sanctuary

The first box held Richard’s shoes.

Eleanor lined them heel to toe on the dining-room rug: black leather, brown suede, and the old tennis shoes he wore when he wanted to look harmless. Dust clung to the soles. One lace had come loose; she tucked it in before she could stop herself.

Then she remembered she no longer had to keep anything tidy for him.

She lifted the shoes into a banker’s box and wrote RICHARD across the lid in block letters. The marker squeaked. In the kitchen, Chloe sat with both hands around a mug gone cold. The broken bear pendant lay beside her, its split metal catching the gray light.

“Do you need me?” Chloe asked.

“I need you to stay where I can find you.”

Chloe nodded. She did not ask what Eleanor was doing. She knew.

The suits came next, pressed and dark, their shoulders still holding his shape. Eleanor carried them from the closet in armfuls. Wool smelled faintly of cedar and aftershave. She packed the briefcase, cuff links, shaving kit, and the framed photograph of Richard with a fishing rod and a smile he had never given the house.

Shared records stayed.

Mortgage statements. Insurance policies. Birth certificates. Tax returns. The employment files he had once called her clutter. Eleanor placed them in a separate cabinet and locked the drawer. His personal papers went into the boxes. His access to the life built inside these walls ended there.

Her phone rang while she sealed the third box.

Richard.

She let it go to voicemail. A minute later, his voice filled the room, sharpened by the recording.

“You cannot lock me out of my own property, Eleanor. That is unlawful. And unless you’ve found a miracle source of income, you cannot maintain the property taxes alone. Think carefully before you make this permanent.”

The message clicked off.

Her fingers tightened around the tape dispenser. Fear rose clean and cold: a bill she could not pay, a roof she could not keep. Richard had always known where to press.

She smoothed the tape.

“You don’t get to buy your way back in,” she said to the empty room.

The locksmith arrived before dusk, a woman named June with a red tool case and a braid down her back. Eleanor showed her every exterior door. June replaced the front-cylinder lock, reset the keypad at the side entrance, and tested the back door twice.

“New code?” June asked.

Eleanor looked at Chloe. “Something he won’t guess.”

They chose Chloe’s graduation date, then changed two numbers.

At the fence, Eleanor spoke to Mrs. Alvarez, three houses down. “If Richard comes by, call me before you let him near the door.”

Mrs. Alvarez’s mouth tightened. “I will.”

The phone rang again.

“I need my documents,” Richard said when Eleanor answered. “The blue folder from the office. Give me access, and I’ll deal with the property taxes. Otherwise, the house is your financial responsibility.”

“Your boxes are secured in the garage. I’ll arrange a pickup.”

“You’re making a mistake.”

“I’m making a boundary.”

She ended the call before he could turn the word into a weapon.

Night gathered against the windows. Eleanor carried the final box to the garage and set it behind the old freezer. Then she returned to the office, where the filing cabinet stood beneath shelves of shared paperwork.

Mortgage. Insurance. Property.

She opened the bottom drawer.

A bank notice lay beneath the tax folder, cream paper creased down the middle. The lender’s name meant nothing to her. Neither did the account number beneath it. Her attention fixed on the signature.

The first loop of the E leaned too far left. The final stroke broke upward.

Not hers.

Eleanor photographed the notice, then the drawer with the folder beside it. On an index card, she wrote the date, time, and exact location. The original went into her evidence box, beneath Chloe’s written record of Richard’s behavior.

The locks protected the doors.

The paper suggested Richard had found another way inside.

## Mourning the Illusion

Rain worried at the locked doors all evening, tapping the glass, then striking harder whenever the wind shifted. The new electronic lock glowed green beside the entry, a small light that meant Richard could not walk in and claim this place as his.

Chloe kept touching the broken bear pendant on the kitchen table. Its chain lay in two coils. One tiny silver ear had snapped from the body. She had not thrown any of it away. That felt too much like agreeing that the child who had waited for Richard had been foolish.

“He loved me once,” she said.

Eleanor stood at the counter with both hands braced against its edge. “He loved the version of himself he got to be with you.”

The words landed cleanly. Chloe turned toward the dark window. Her reflection hovered over the rain, pale and divided.

“I miss him,” she whispered.

“I know.” Eleanor’s voice roughened. “You can miss him and still keep him out.”

Chloe pressed her thumb into the pendant’s broken seam. The metal bit her skin. “What if keeping him out ruins us?”

“He already spent years doing that.”

Eleanor crossed to the table and sat. For a moment, she looked older than the storm, her face hollowed by all the rooms she had carried alone.

“I helped build him,” she said. “I typed his reports. Covered his travel. Made excuses when he came home smelling like another town. I protected his reputation because I thought endurance was loyalty.”

Chloe lifted her gaze.

“I thought if I worked hard enough, he would become grateful,” Eleanor continued. “That was my mistake. But the work is still mine. The records are still mine. I know where the lies repeat.”

“You don’t have to defend him anymore.”

“I’m not going to.” Eleanor pulled a stack of folders from the filing cabinet. “We document. Preserve originals. Let counsel decide what survives.”

The kitchen table became a map. Chloe spread the Fort Wayne video, toll records, anonymous debit-card statements, receipts, and Richard’s recorded admissions across one side. She wrote dates in a ruled notebook, matching them to gas purchases and hotel charges.

“Employment misconduct,” she said, drawing a line down the page. “Travel, tolls, meals, hospital-equipment claims.”

“Assets and contributions.” Eleanor placed property-tax receipts, mortgage statements, and years of household records in a second pile. “What I paid. What he borrowed. What he moved.”

Chloe touched the third pile, thinner than the others. “Forged-signature question.”

Neither spoke for several seconds.

“Every claim gets a source,” Eleanor said. “No guesses.”

“No confrontation.”

They photographed each page with Eleanor’s phone, slid the originals into labeled envelopes, and sealed them with clear tape. Their shoulders brushed as they worked. The contact felt unfamiliar, then steady - a family structure built from presence instead of promises.

Chloe wrote the chronology until the storm softened. The work might uncover debts, missing money, a house they could lose. Fear tightened beneath her ribs, but she kept writing.

Eleanor opened the filing cabinet’s last drawer. “This came in the mail.”

The notice bore a lender’s logo neither of them recognized. Beneath it, a reference number ran in black type.

Chloe copied it into the notebook.

“What account is that?” Eleanor asked.

Chloe looked at the locked door, then at the sealed papers.

“I don’t know,” she said. “But it’s tied to this house.”

## Tracing the Drained Equity

The lender’s logo looked harmless until Eleanor read the number beneath it.

She held the notice flat against the kitchen table, one palm pinning its damp corner. A blue square. A clean white house. Nothing like the bank that had carried their mortgage for twenty-eight years. The account number belonged to their address, though, and beside it waited the balance.

$80,000.

Her mouth dried. Richard’s warning about property taxes had sounded like another accusation, another way to make her feel careless while he moved money beyond her reach. This was different. The house itself had been opened like a drawer.

Chloe leaned over her shoulder. “Home-equity line of credit.”

“Active,” Eleanor said. The word scraped out. “He told me the taxes were behind.”

“He didn’t tell you about this.”

Eleanor turned the notice over. No signature. No explanation. Only a customer-service number and an instruction to report unauthorized activity immediately.

She called from the landline. Hold music chimed through the kitchen while rainwater ticked from the gutters. When a woman answered, Eleanor gave her name, the property address, and the account number. She kept her voice level until the representative asked whether she had authorized the line.

“No.”

The representative transferred her to fraud.

A man named Daniel asked security questions, then went quiet while he pulled up the file. Eleanor listened to the faint clicking of keys. Her fingers pressed crescents into the notice.

“The line opened fourteen months ago,” Daniel said. “Initial limit, eighty thousand. Current balance, seventy-nine thousand six hundred and twelve.”

“Who signed the application?”

“We can provide certified copies. I need to note your dispute first.”

“I am disputing the signature.”

Daniel paused. “The scanned application bears a version of your name. We can’t determine authenticity by sight alone, but I can open a preliminary fraud file and request forensic review.”

“Can you freeze it?”

“Not solely on a verbal statement. We can flag the account. Reversal of the lien, liability determination, and relief from repayment require certified records, forensic examination, and legal process.”

The chair seemed to shift under her. Years of cooking, cleaning, postponing courses, stretching every paycheck until it thinned - all of it had become security for money she had never touched.

“Send everything certified,” she said. “Every application, draw, transfer, and payment record.”

Daniel promised delivery through the secure portal and by mail. Before ending the call, he added, “Do not alter or discard any original documents.”

Chloe brought out her laptop. Together they built columns: date, amount, destination, explanation. The first draw went to a private academy under Leo’s name. The second matched the truck dealer’s deposit, down to the last dollar. Smaller withdrawals aligned with insurance, registration, and a tuition installment already visible in the debit-card trail.

Chloe traced each line with her finger. “He used the house to fund them.”

Eleanor stared at the copied signature in the scanned application. The loops resembled hers from a distance, but the pressure was wrong. Her real hand dug into paper on the downstroke. This one floated, imitating the shape without knowing the person.

They scanned the notice, saved the portal files twice, and returned the originals to the filing cabinet. No call to Richard. No accusation across the house. If he knew what they had found, he could move other accounts, revise explanations, make evidence disappear behind another locked drawer.

Daniel called back before noon. The fraud file had been assigned a number. The HELOC could not yet be frozen, and other marital assets might remain accessible to an authorized borrower.

Eleanor wrote the file number beneath the account balance.

The house was not safe because she was angry. It would be safe only if someone who understood the law moved before Richard did.

“We need a lawyer,” she said.

Chloe closed the laptop. “Today?”

“Today.”

## The Retainer from Independence

The email arrived while Chloe Vance rinsed a coffee cup. Its subject glowed against the cracked screen: **Offer Confirmed - St. Agnes Nursing Residency**.

She dried one hand on her jeans and opened it.

Top-ranked candidate. Start date. Signing advance.

The number at the bottom tightened her grip. Enough to matter. Not enough to quiet the fear.

Eleanor Vance looked up from the bank folders spread across the kitchen table. “What is it?”

“I got it.” Chloe read the sentence twice. “They want me.”

“They wanted the person who earned it.” Eleanor’s smile came carefully, as if joy had become something breakable.

That afternoon, Chloe transferred the advance into a new account. The bank clerk printed the receipt and slid it beneath the glass. Her name stood alone on the line. No Richard Vance. No household designation. Just Chloe.

Outside, traffic hissed over wet pavement. She tucked the receipt inside her coat and listed other uses for the money: replacing the stolen equity, paying down the mortgage, buying Eleanor time. A repair fund. A bridge back to the life Richard had cracked open.

“I could put it toward the house,” Chloe said when she returned.

Eleanor closed the HELOC folder. “You could.”

The words offered no permission.

“I could keep us from losing more.”

“Your work is not a patch for his damage.” Eleanor touched the receipt with one finger. “This is for your future.”

Future landed harder than the bank’s warning that Richard might move other assets. It meant the family might not be restored. No achievement, no perfect answer, no obedient daughter could summon him back to the table.

Eleanor folded her hands over the archived contribution records. “I accepted a teaching position.”

Chloe blinked. “You did?”

“Adult education. Small-business accounting and practical finance. They liked that I ran half a household and kept records no one else understood.” A dry laugh escaped her. “Apparently that counts as experience.”

“It counts as everything.”

They opened accounts at another bank, changed passwords, canceled the shared debit card, and moved legitimate deposits beyond Richard’s ordinary reach. Bank statements, toll records, receipts, employment letters, and the forged eighty-thousand-dollar HELOC went into labeled envelopes. Each page made the separation heavier, more solid. Paper could become a wall.

Mara Singh’s office smelled of cardamom tea and toner. She listened without interrupting as Eleanor described the bank’s irregularity notice. Dates, amounts, and names accumulated beneath Mara’s pen.

“Suspicion is not proof,” Mara said. “We need authenticated records, preservation notices, and a documented property claim. We’ll request originals and protect the chain of custody.”

Not a family argument. A case.

Mara aligned the folders. “These expenses recur across travel, tolls, fuel, rail, meals, and hotels. The pattern connects the household transfers to the same town, the same intervals, the same business explanations.”

Chloe’s mouth went dry. Richard had believed repetition could make a disguise permanent.

“What does it cost to begin?” she asked.

Mara named the retainer.

The number sat between them, clean and final. Chloe pictured the pendant broken in her palm, every year spent polishing herself for Richard’s approval. Then she signed the authorization and transferred the money.

Mara accepted it. “I’ll send preservation notices first thing tomorrow.”

Tomorrow had a shape now.

“And after that?” Eleanor asked.

Mara’s gaze settled on the employment records. “After that, we examine what his employer was paying to support.”

Richard’s concealed household had stopped being only a private betrayal. It was becoming an employment case.

## Pulling the Plug on His Reputation

The metal box had left a dark square on Mara’s desk, as if it had been lifted from a fire.

Eleanor kept her hand on the lid. The latch pressed a crescent into her thumb. Around it lay bank statements, debit-card pages, toll logs, rail tickets, gas receipts, hotel folios, and meal slips Richard Vance had once dismissed as incidental business costs. Paper rasped against paper as Mara drew each stack toward her.

“Start with the dates,” Mara said.

She cleared a long strip across the desk and arranged the records in rows. January. March. May. Fort Wayne appeared again and again, a name that had lived in Eleanor’s mind as a private ache and now sat in black ink beneath Mara’s ruler.

Richard’s hospital-equipment trips claimed one direction. The toll passages pointed another. A rail ticket placed him in Fort Wayne on a Thursday night. A gas purchase put his car there the next morning. The hotel charged two nights. His expense report listed a supplier visit three counties away.

“One trip could be a clerical error.” Mara tapped the first overlap with her pencil. “Two could be sloppy reporting. But this?”

Eleanor leaned closer. The same hotel chain. The same exit. Meals bought after dark. Amounts rounded just enough to look clean. Every route bent toward Julianne’s town.

“He used the same explanation,” Eleanor said. Her voice scraped. “Hospital equipment. Demonstrations. Emergency calls.”

“And the same private destination kept appearing beneath it.”

Mara wrote corroboration in the margin, her letters narrow and deliberate.

Not proof.

The words steadied Eleanor and frightened her. Proof was what she had wanted when she confronted Richard, something he could not laugh away or turn against her. Yet the pages did not shout. They accumulated. They waited.

“What if his employer says I built this out of spite?” Eleanor asked. “What if Richard says I’m punishing him for the marriage?”

Mara folded her hands over the matrix. “Then we don’t accuse him of a crime. We preserve the records. We request discovery. We authenticate the timeline. The workplace claim concerns expenses and representations. The property claim concerns the eighty-thousand-dollar forged HELOC and the household loss. Each process carries its proper weight.”

The office smelled of cold coffee and lemon cleaner. Outside, a truck groaned through the intersection. Eleanor pictured Richard’s face when she demanded the truth: the quick flare of indignation, the practiced injury. Another confrontation would give him a room, a target, and time to rehearse.

Mara slid a fresh authorization across the desk. “May I organize copies for counsel and potential employer discovery? I’ll retain the originals in a controlled file and prepare preservation notices. Richard has not been notified.”

Eleanor opened the metal box.

Her fingers hovered over the receipts, then released them. One by one, she handed the originals across the desk. The surrender tightened her throat. It also loosened something beneath her ribs.

By dusk, Mara had completed the expense matrix: date, destination, claimed business purpose, actual travel indicator, suspected household benefit. The pattern justified preservation and a fiduciary review. It was not yet a verdict.

Mara lifted the final hotel receipt. “Wait.”

She placed it beside the notation from the forged HELOC paperwork. Three initials marked both documents, slanted in the same careless hand.

Eleanor studied the matching strokes.

Richard had left a signature where he thought no one would look.

## The Mistress's Entitlement

The phone rang before Eleanor finished labeling the last bank statement.

Julianne.

Her name glowed on the kitchen counter, bright as a warning light. Eleanor set her pen beside the expense matrix and opened the recording app Mara had instructed her to use. Ohio law permitted her to preserve her own conversation. She tapped record, then answered.

“What did you do to Richard’s accounts?”

Julianne’s voice came through the speaker, sharp with panic and blurred by a bad connection. Traffic hissed behind her over wet pavement.

“I’m not sure what you mean.”

“The transfers stopped. The tuition payment bounced. The truck lender called Leo’s phone. Our landlord says the rent is late.” Julianne drew breath, gathering force. “You froze everything.”

Eleanor studied the columns she had built through the night: dates, amounts, destinations, Richard’s descriptions. Her fingertips rested on the cool rim of her coffee cup.

“What payments are you referring to?”

“You know exactly which ones. Leo’s tuition - eighteen hundred every month. The truck, six hundred and forty. The rental house in Fort Wayne, two thousand, plus utilities when Richard traveled.”

“Traveled for what?”

A pause. Then Julianne laughed without humor. “For work. He had equipment accounts there. He told you that, didn’t he?”

“He told me many things.”

“Well, he chose to help us because we’re his family.” Each word landed cleanly, placed for damage. “You were always an obstacle, Eleanor. You had the house, the insurance, the respectable name. He had to build something real with us.”

Eleanor kept her voice level. “When did he begin paying the tuition?”

“Two years ago. Maybe a little more. He said Leo shouldn’t have to start behind everyone else.”

“And the truck?”

“Last spring. Richard said the old one was unsafe. He made the down payment and handled the monthly bills.”

“From which account?”

“His business account, mostly. Sometimes the household account. He said it was reimbursement for mileage and supplies.” Anger loosened Julianne’s tongue. “The tolls, hotels, meals - all of it connected to his routes. He’d stop here after Fort Wayne appointments. He told me not to worry about receipts because the company owed him.”

Eleanor wrote each phrase beneath the appropriate date. The refrigerator clicked on. Cold air slipped across her ankles.

“Did he say anything about the house?”

Julianne’s breathing changed. “What house?”

“The one where I live.”

“He said it would be ours eventually.” The certainty in her voice stopped Eleanor’s pen. “After things were settled. After you moved out or signed whatever papers you needed to sign. He said Leo and I would finally have security, not some rented place dependent on his paycheck.”

“Did he name a date?”

“He said soon. He said the house was practically his because he had paid for everything that mattered.”

Silence opened between them, filled by the distant rush of traffic.

Eleanor closed the notebook. “I’ll review the payment issue.”

“You’d better fix it,” Julianne said. “Richard promised us. You can’t take that away because you’re bitter.”

The call ended.

For several seconds Eleanor remained still, the phone warm in her palm. Then she saved the recording under the date and account-freeze time, exported the transcript, and attached her notes. Mara received the file before the kettle finished boiling.

Her reply arrived twelve minutes later.

This is corroboration, not the whole case, Mara wrote. It supports the diversion pattern and the disguised workplace expenses. Preserve every original file. And Eleanor, if Richard promised Julianne the house, he may have promised someone else something similar.

Eleanor read the sentence twice.

The frozen account statements lay beside the forged HELOC papers. The house no longer felt like shelter. It felt like a target with a clock running inside its walls.

She opened a new message to Mara.

What is our next institutional move?

Then she pressed send.

## The Auditing Storm

The summons arrived while Richard dictated a victory note to a client.

**Formal meeting request. Document-preservation notice. Immediate compliance.**

He read it twice, then snorted at the screen. Someone in legal had found a new way to make ordinary paperwork sound criminal. His sales numbers still stood. Hospitals still returned his calls. A clean explanation would clear the fog.

At two, Denise Halpern from compliance met him outside a windowless conference room. Tom Arnett, his supervisor, sat beside her, a folder squared precisely to the table.

“Is this about the Fort Wayne expenses?” Richard asked.

Denise indicated the chair. “Please sit.”

He sat without removing his coat. The room smelled of burnt coffee and printer toner. A recorder blinked red between them.

Denise slid a spreadsheet across the table. Fort Wayne hotel, March third. Interstate tolls, March third and fourth. Gas near the hospital district. A rail ticket from the same weekend. Meals for one, then another meal twelve miles away. A second hotel the following month. A third trip two weeks after that.

“These correspond to hospital-equipment claims,” Denise said.

“They correspond to clients,” Richard said. “Fort Wayne has several facilities. I was expanding the territory.”

Tom’s fingers tightened around his pen. “Which facilities?”

Richard named two. The names came easily. He had sold to both years ago.

Denise turned the page. “Neither facility records a visit on these dates.”

“Schedules change. Meetings get canceled. You still incur expenses.”

“The claims describe equipment demonstrations.”

“Demonstrations can move.”

She set the rail receipt beside a dinner charge, then the hotel folio. The dates lined up like teeth. Richard reached for the spreadsheet. Denise kept one hand on it.

“Are you saying every entry is accurate?” she asked.

“I’m saying I did my job.”

“Then the records will support that.”

The recorder’s red light seemed to brighten. Someone would read his explanations later, pausing over every hesitation. He had always trusted confidence to fill gaps. Now the gaps had dates, addresses, and dollar amounts.

Denise folded her hands. “Your email, expense files, travel records, and company devices are being preserved and reviewed. Do not delete, alter, or retrieve anything related to this matter.”

“I have nothing to hide.”

“Preservation is procedural,” Tom said. “This is a fact-finding investigation, not a criminal finding.”

The distinction offered no comfort. Fact-finding meant they had not decided what he was. It also meant they were still deciding.

Denise asked for his company card. Tom asked for his keys, phone, and laptop. Richard held each item a moment too long before surrendering it. The badge came last, its plastic edge pressing into his palm.

“You are suspended immediately, pending investigation,” Tom said.

“Suspended?” Richard rose so fast the chair struck the wall. “After everything I’ve brought in?”

“No access to company systems or property during the review.”

Outside, the company car’s engine refused to turn. The dashboard stayed black. His badge failed at the building door, a small red light denying him.

He called Julianne Foster. No answer.

He called Eleanor Vance. An attorney’s office answered in a guarded voice: she would not speak with him.

He called Chloe Vance. The call rang until voicemail. He left nothing. What could he say that would make her remember who needed whom?

His laptop bag weighed nothing without the computer. He sat in his own car and watched the company phone display one last message from Chloe: **I’m at the clinic. Please stop calling.**

Then the screen refreshed.

**Account locked. Contact administrator.**

Richard stared until the words blurred. Without the badge, the card, the car, and the devices, he had no proof that the man in the driver’s seat still mattered.

## The Ambush at the Clinic

After leaving the company building, Richard crossed town to the hospital that housed Chloe’s outpatient clinic. By the time she came off shift, he was waiting beside the employee entrance as though the hospital itself had summoned him.

Chloe stopped beneath the buzz of the security lamp. Rain glazed the asphalt. The wet air carried bleach from the service doors. The shift still ached between her shoulder blades, and inside her pocket, the broken bear pendant pressed a jagged edge into her palm.

No company sedan waited at the curb. No polished leather folder. No phone bright with executive messages. Richard wore a wrinkled blue shirt and held himself stiffly inside a borrowed coat. At the far end of the lot, a city bus sighed diesel into the cold.

“Chloe.”

His voice still knew how to reach for the child in her. Her shoulders drew in before she caught them. She closed her fingers around the pendant until the metal bit.

“You shouldn’t be here.”

“I needed to talk to you.” He glanced toward the staff entrance, then back at her. “Your mother is moving forward with this. The lawyers, the audit, all of it. You can stop it.”

Exhaustion put an edge on her answer. “I can’t stop anything.”

“You can persuade Eleanor.” His mouth twitched around the name, as though it belonged to a stranger. “Tell her this is a misunderstanding. My suspension is temporary. The company froze my card and access because they have to investigate. That doesn’t mean I stole anything.”

Nothing about the diverted money. Nothing about the forged HELOC or the expense claims that traced his visits to Julianne’s town. He kept his hands open, palms visible, performing helplessness.

“The employer investigation is finished,” Chloe said. “The company authenticated the expense trail. Mara sent word this afternoon that its review is complete. The debit-card charges, toll records, and Fort Wayne timestamps match the claims. The same initials appear on those claims and on the forged HELOC application. Your company suspended you, froze your privileges, and turned the file over to counsel.”

The color left his face. “You gave them that?”

“I gave Mara what I’d already documented. The company verified the rest.”

“You’re my daughter.”

There it was - the old key turning in the old lock.

She remembered waiting outside his office as a girl, rehearsing good news until he looked up. She remembered the bear pendant whole against her throat. She remembered accepting the nursing position and its signing advance, and knowing for the first time that her future did not require his approval.

“I’m your daughter,” she said. “I’m not your messenger.”

Richard stepped closer. His coat carried the stale smell of someone else’s car. “Ask Eleanor what evidence she has. Ask Mara what she plans to do. If they understand the damage this will cause, they’ll reconsider.”

Not *How are you?* Not *Are you sleeping?* Not *Did the shift go well?*

Only evidence. Mara. Damage.

The pattern settled into place with the finality of a chart stamped and filed. His fear was not for her. It was for the doors closing around him.

“Communicate through Mara,” Chloe said. “Through the formal process. If you have an explanation, give it there. The authenticated records will be part of mediation.”

His jaw tightened. “You would leave me exposed like this?”

“You exposed yourself.”

For a moment, the parking lot held only the ticking of a cooling engine and the rattle of a cart beyond the service doors. Richard looked past her toward the hospital windows, searching for an audience that might still grant him authority.

“Court records can make Eleanor look like the abandoning spouse,” he said. “People believe the one who walks away is cruel. You really want to help her do that?”

Chloe’s throat burned. The plea had sharpened into a warning, delivered in the same voice that had once kept her outside his office rehearsing better news.

She stepped around him. Her shoes crossed the painted line and struck rough blacktop. Behind her, Richard called her name once.

She did not turn.

The records would answer him: the preserved messages, the ledgers, the signatures, and the expense trail his employer had authenticated. They would show who had carried the family and who had walked away long before anyone filed a claim.

At the edge of the lot, Chloe unlocked her car. She opened her hand. The broken pendant lay against her palm, no longer a key.

She placed it in the console beside her nursing orientation packet and drove toward the life she had chosen for herself.

## Stripped of Every Feather

Mara laid Eleanor’s life across the table, one document at a time.

First came the ledgers, their cloth spines softened beneath Eleanor’s hands. Then the directors’ contact book, her resignation letter, the jewelry slips, certified bank records, and the expense chronology. Paper whispered over polished wood. Bitter coffee cooled in untouched cups.

Richard regarded the display as though someone had emptied a rubbish drawer at his feet.

His counsel adjusted his glasses. “Mr. Vance’s assets derive primarily from his professional earnings.”

Eleanor pressed her thumb against the ridged edge of her wedding ring. For thirty years, a sentence like that had sent her scrambling to justify herself: dinners reheated after midnight, children soothed alone, opportunities declined before anyone else knew they existed. The old heat crept up her throat. She kept her hand still.

Mara touched the first ledger.

Eleanor let go of the ring. “March eighth, 1994. I paid the incorporation fee.”

The next entry showed the office rent, paid from her savings. The contact book held the names of two directors she had introduced to Richard, both of whom later hired his fledgling firm. Her resignation letter fixed the date she surrendered her own advancement. The jewelry slips recorded what she sold when his first major client paid ninety days late.

Richard shifted in his chair. “That was family money.”

“Yes,” Eleanor said. “That is the point.”

The mediator turned a page.

Richard’s counsel tried again. “Old household arrangements do not establish ownership of a career.”

“No one is claiming his career,” Mara said. “We are documenting her contribution to the marital estate.”

She opened the employer records. Every Fort Wayne trip carried an authenticated expense entry: altered destination codes, disguised lodging, meals charged on weekends Richard had called emergency travel. His employer stopped short of criminal conclusions, but the consequences filled the file. Suspension. Company card revoked. Vehicle surrendered. Email and professional privileges terminated.

“These aren’t Eleanor’s interpretations,” Mara said. “They’re the company’s records.”

The color left Richard’s face.

The bank documents came last. Eighty thousand dollars drawn against the house. Eleanor’s name formed by another hand. Transfers traced to Leo’s tuition and a down payment on a truck.

“I helped a boy,” Richard said. His voice had gone small. “Whatever else happened, I helped him.”

“With my house,” Eleanor said.

He searched her face for the woman who had swallowed pain to preserve his dignity. “We could keep this private. Work something out between us.”

Chloe had refused him at the clinic. Now he wanted Eleanor to carry the mercy their daughter had set down.

Eleanor slid the preservation demands toward the mediator. The accounts were identified. Retirement assets disclosed. Transfers restricted pending review. No quiet liquidation. No vanished balance. No final gift purchased with her future.

“We are working something out,” she said. “Permanently.”

The word landed cleanly. It closed no door she wished to enter.

The mediator folded his hands. “Mr. Vance, unresolved civil findings may deepen your employment exposure and support further referral. No final allocation will be made today. But the assets are preserved, and the documentary record is substantial.”

Richard’s shoulders bowed. His claim to being self-made had been dismantled into dates, entries, signatures, and receipts.

“Settlement,” the mediator said, “is your last opportunity to negotiate before this record becomes formal findings.”

Eleanor did not touch her ring again.

## The Courthouse Capitulation

The house became hers in twelve-point type.

Mara Singh set one finger beside the paragraph. “Free of Richard’s ownership claim. No deferred interest. No right of occupancy.”

Across the courthouse table, Richard Vance stared at the settlement as if the pages had betrayed him. Without his tailored jacket, company car, and polished authority, he looked diminished. The room smelled of hot toner and stale coffee. Beyond the closed door, a clerk called a case number.

Mara turned to the next tab. “Richard assumes the entire eighty-thousand-dollar HELOC obligation. Eleanor’s retirement share will transfer through a qualified domestic relations order, without requiring his cooperation afterward.”

Richard’s counsel cleared his throat. “We have reviewed the supporting materials.”

Supporting materials. Bloodless words for Eleanor’s ledgers; her contact book, filled in careful script; the resignation letter marking when she had abandoned her career; the jewelry slips and bank statements; two decades of money diverted to Julianne Foster and Leo.

“If litigated,” counsel continued, “the authenticated records could support findings unfavorable to Mr. Vance.”

Could landed softly. Richard’s jaw tightened.

He asked for five minutes alone with Eleanor.

Mara refused.

“He can speak here,” Eleanor said.

Richard leaned toward her. “After twenty-five years, you want strangers deciding what happens to us?”

The old heat rose along Eleanor’s neck - the shame of making private failure visible, of letting other people see what endurance had cost her. She kept both hands on the table.

“No. I want the agreement to decide what happens to the property.”

“I’ll sign if we go home and discuss this privately. We can say we separated because of pressure. We don’t have to destroy everything.”

His last bargain: cooperation purchased with her silence, reconciliation shaped like another locked room.

Eleanor traced the settlement’s edge. Paper rasped beneath her fingertip.

“I spent twenty-five years protecting what I believed we had,” she said. “I won’t spend another day protecting what you did.”

His face hardened. “You owe me some discretion.”

“I owe the truth nothing but accuracy.”

Mara pushed the signature page forward. “This settlement resolves the marital property claims. It does not end the employer investigation, reverse the suspension, restore company access, or prevent referrals involving forged or misused records.”

Richard’s counsel bent close to him. Eleanor caught fragments: litigation, exposure, findings. Each word stripped away another hiding place.

Richard signed.

He signed the deed provisions, the HELOC assumption, the retirement-transfer authorizations, and every acknowledgment Mara placed before him. His pen tore across the paper, then stopped.

Eleanor reread the transfer language. No side letters. No future consent. No promises she would have to coax him into keeping.

She signed her name.

Grief pressed beneath her ribs - not for Richard, but for the woman who had believed endurance would earn gratitude. With the pen, Eleanor released her.

Outside, the certified copies weighted her hand. On her phone, the bookkeeping program’s teaching offer waited for an answer.

She pressed Accept.

Below it, a message from Chloe read: Clinical placement confirmed. Dinner at home tonight?

Home. Not Richard’s house. Not the reward for keeping quiet. The place they would choose, and keep choosing, by showing up.

Behind her, Richard raised his phone.

“Julianne,” he said when the call went unanswered. “Pick up.”

Eleanor descended the courthouse steps into the noon light. Her records had protected her where love, patience, and silence never had.

## The Parasite Scattered

Richard arrived in a rideshare with two suitcases and a banker’s box balanced on his knees.

From the kitchen window, Julianne watched his card fail twice. By the time he reached the porch, his face looked gray beneath the parking-lot lights. No company sedan. No pressed suit. No clipped conversation through an earpiece while someone else carried his bags.

He knocked.

She let him knock until Leo came downstairs.

“Is he moving in?”

“Just open up, Jules,” Richard called through the door.

The old nickname had lost its shine. Julianne unlocked the dead bolt but kept one hand braced against the door.

“What happened to the car?”

“Company property.” He leaned forward.

She held her ground. “And everything else?”

His gaze slid toward the envelopes spread across her kitchen table: rent past due, truck payment delinquent, Leo’s program balance due before registration. Paper had replaced every promise Richard had made.

“There was a settlement,” he said. “Temporary restrictions. Once the employment matter is resolved, I can rebuild.”

“From what?”

“I have contacts.”

A laugh caught in her throat and came out hard. “Can they pay Friday’s rent?”

His jaw tightened. “I need you to stay calm.”

Leo entered the hallway, barefoot, his shoulders drawn high. “They’re taking the truck?”

“No one is taking anything.” Richard lowered the banker’s box. “We have time.”

“The notice says cure by the eighteenth.”

“We’ll negotiate.”

“With what?” Julianne asked.

The refrigerator’s uneven hum filled the silence.

Richard pulled settlement papers from the box and tapped figures he did not explain. The house remained Eleanor’s. Accounts had been divided or secured. His salary existed only in old statements. Whatever came next depended on investigations, lawyers, and work he no longer had.

Leo stared at the notice. Red climbed his neck. “You said my last year was covered.”

“It will be.”

“You said the truck was safe.”

“Leo, don’t pile on.”

The boy flinched.

Julianne had mistaken dependence for protection. Richard had taught Leo to stand beneath an umbrella he never owned, then blamed him for getting wet.

“Go upstairs,” she said.

Leo folded the notice into quarters and left without looking back.

Richard lowered his voice. “We chose each other. That has to mean something now.”

There it was: loyalty presented as another bill.

For years, Julianne had measured love in keys, tuition receipts, dinners, the truck gleaming outside. She had known about Eleanor. She had suspected where some of the money came from. Even so, Richard’s spending had made her feel chosen - lifted above the wife he called cold and the daughter he called ungrateful.

Heat pressed beneath Julianne’s collar. She pictured Eleanor opening statements, Chloe hearing herself dismissed, and Julianne accepting each bright purchase without asking which dark place it had come from.

Now Richard wanted shelter inside that story because the money had run out.

“You chose us when we were affordable.”

His face hardened. “After everything I’ve done for you?”

Julianne seized both suitcases. Their corners struck her shins as she hauled them outside. Cold air slipped beneath her blouse. Richard followed, murmuring threats shaped like reason.

She set the bags beside the porch rail.

“You can’t stay here. I won’t pay for you, feed you, or help you wait this out.”

“Julianne.”

She closed the door and turned the dead bolt.

Later, she opened the birthday video on her phone. Richard stood beside Leo’s new truck, smiling as everyone cheered.

Once, the image had proved he chose them.

Now it showed how easily he had made stolen security look like love.

## A Chair Filled with Light

The certificate arrived to applause, and Chloe did not wonder whether her father would have been proud.

That surprised her more than the embossed seal beneath her thumb. Nurses crowded the hospital education room, carrying the smells of coffee, sanitizer, and twelve-hour shifts. Someone whistled. Her manager hugged her. Mara Singh lifted her phone and ordered Chloe to smile like a woman who had just earned her critical-care certification.

Chloe laughed for the picture.

She had earned this. Not Richard’s daughter. Not the girl watching an empty chair at graduation. Chloe Vance, RN, whose signing bonus had paid Mara’s retainer and opened the first door to a life built by her own labor.

In the parking garage, her phone warmed her palm.

For half a breath, the old reflex returned: check whether Richard had remembered the date. Imagine what he might have written if regret had ever taught him courage.

The screen held nothing from him.

Chloe slipped the phone into her bag without opening his contact. The urge passed, small and clean, like a stitch drawn from healed skin.

Richard had made one last appeal in person before signing the settlement papers. He had asked Chloe to remember who he had been before “all this.” She had asked where her ceremony had taken place - the one he had refused even to ask about.

He could not answer.

Whatever he wanted from her had ended in that silence.

The drive home carried her beneath trees beginning to bronze. When she turned onto the familiar street, sunlight flashed across new shingles. No tarp. No sagging gutter. The repaired roof held the evening light as if the house had learned to lift its face.

Six months had passed since the courthouse settlement. Eleanor owned the house now. Richard had refinanced the eighty-thousand-dollar HELOC balance in his name, and the lender had released Eleanor and lifted its lien from the property. The unfamiliar lender on the old statements had been the HELOC lender all along. The retirement transfer had cleared.

The final accounting had answered the remaining questions. Bank records traced the account access to Richard’s phone. The pickup truck he had presented as a gift had been paid for with a HELOC draw routed through their joint checking. His abandonment story had bought him no leverage in mediation; the records outlasted every version of the marriage he tried to tell.

Numbers could not restore the years he had consumed. They could stop him from taking more.

Eleanor met her on the porch, flour dusting one cheek.

“There she is.” Her gaze dropped to the certificate. “My terrifyingly qualified child.”

“Your terrifyingly qualified child wants dinner.”

“Good. I made too much.”

Inside, papers covered the hall table, each marked with Eleanor’s tidy blue notes.

“Another term?” Chloe asked.

Eleanor touched the top syllabus, almost shyly. “Two courses. They asked for three.”

“And?”

“I said no.” A smile gathered at one corner of her mouth. “I like teaching. I don’t like being devoured by it.”

Choice sat easily in her voice now. Her income bought books, train tickets, the blue kitchen tile she had chosen. It no longer stood between them and disaster.

Mara called from the dining room. “Are we eating, or should I start the cake unsupervised?”

Chloe stepped through the doorway and stopped.

The long formal table was gone. A round oak table stood in its place, warm beneath the sinking sun. No head. No reserved seat. No chair staged for a man whose absence demanded more attention than everyone present.

Eleanor propped the certificate against the flowers.

Mara raised her glass. “To Chloe Vance, who knows exactly what she’s doing at least sixty percent of the time.”

“An exceptional hospital average,” Chloe said.

Their laughter moved through the room, easy and imperfect. Chloe let their pride reach her without turning it into debt. She did not have to purchase tomorrow’s affection by accepting tonight’s.

The broken bear pendant could remain among the things Richard had abandoned. His silence belonged to him.

Sunlight filled the room, touching every face, every plate, every open hand. Family was not blood demanding entrance. It was truth spoken, care repeated, presence freely given.

Around the table, every chair belonged to someone who had chosen to stay.
