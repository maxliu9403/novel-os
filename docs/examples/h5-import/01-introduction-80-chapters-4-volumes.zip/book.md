---
novel_os_schema: "novel-classification.v1"
novel_os_catalog: "novel-types.2026-09"
classification_id: "classification:a510e3c635cd991a0f0bdee934d282dc297e50a21bd5abde5c0f9096dc96992f"
primary_genre_id: "womens_fiction"
secondary_genre_ids: ["family_drama"]
story_type_ids: ["revenge", "domestic_betrayal"]
tone_ids: ["angst"]
setting_ids: ["family_domestic"]
filter_type_ids: ["womens_fiction", "family_drama", "revenge", "domestic_betrayal", "angst", "family_domestic"]
audience_channel: "female"
audience_age_band: "midlife"
length_form: "long"
chapter_band: "chapters_51_100"
serialization_schema: "novel-serialization.v1"
serialization_id: "serialization:8c457cf22d0af88bf4119aa4d6a5a9a66d06cfcb6fa78e2658c2565b9b0b9250"
narrative_format_id: "narrative-format:2b90533ca027cc8febb151bce49a61bd6dd18379a5e3e7db2c9a1f960af2d81e"
narrative_mode: "multi_volume"
total_chapters: 80
volume_count: 4
series_id: ""
---

# The Letter at Wren Harbor — H5 Integration Fixture

*Novel OS Test Fixture · Women's Fiction*

## Introduction

This is a technical import fixture. Claire finds a letter, confronts a family secret, and makes a choice. This introduction must not count as chapter one or consume a free-trial slot.

## Chapter 1: Test Choice

This is story chapter 1 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 2: Test Choice

This is story chapter 2 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 3: Test Choice

This is story chapter 3 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 4: Test Choice

This is story chapter 4 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 5: Test Choice

This is story chapter 5 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 6: Test Choice

This is story chapter 6 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 7: Test Choice

This is story chapter 7 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 8: Test Choice

This is story chapter 8 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 9: Test Choice

This is story chapter 9 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 10: Test Choice

This is story chapter 10 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 11: Test Choice

This is story chapter 11 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 12: Test Choice

This is story chapter 12 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 13: Test Choice

This is story chapter 13 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 14: Test Choice

This is story chapter 14 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 15: Test Choice

This is story chapter 15 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 16: Test Choice

This is story chapter 16 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 17: Test Choice

This is story chapter 17 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 18: Test Choice

This is story chapter 18 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 19: Test Choice

This is story chapter 19 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 20: Test Choice

This is story chapter 20 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 1.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 21: Test Choice

This is story chapter 21 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 22: Test Choice

This is story chapter 22 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 23: Test Choice

This is story chapter 23 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 24: Test Choice

This is story chapter 24 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 25: Test Choice

This is story chapter 25 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 26: Test Choice

This is story chapter 26 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 27: Test Choice

This is story chapter 27 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 28: Test Choice

This is story chapter 28 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 29: Test Choice

This is story chapter 29 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 30: Test Choice

This is story chapter 30 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 31: Test Choice

This is story chapter 31 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 32: Test Choice

This is story chapter 32 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 33: Test Choice

This is story chapter 33 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 34: Test Choice

This is story chapter 34 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 35: Test Choice

This is story chapter 35 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 36: Test Choice

This is story chapter 36 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 37: Test Choice

This is story chapter 37 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 38: Test Choice

This is story chapter 38 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 39: Test Choice

This is story chapter 39 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 40: Test Choice

This is story chapter 40 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 2.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 41: Test Choice

This is story chapter 41 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 42: Test Choice

This is story chapter 42 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 43: Test Choice

This is story chapter 43 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 44: Test Choice

This is story chapter 44 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 45: Test Choice

This is story chapter 45 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 46: Test Choice

This is story chapter 46 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 47: Test Choice

This is story chapter 47 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 48: Test Choice

This is story chapter 48 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 49: Test Choice

This is story chapter 49 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 50: Test Choice

This is story chapter 50 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 51: Test Choice

This is story chapter 51 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 52: Test Choice

This is story chapter 52 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 53: Test Choice

This is story chapter 53 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 54: Test Choice

This is story chapter 54 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 55: Test Choice

This is story chapter 55 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 56: Test Choice

This is story chapter 56 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 57: Test Choice

This is story chapter 57 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 58: Test Choice

This is story chapter 58 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 59: Test Choice

This is story chapter 59 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 60: Test Choice

This is story chapter 60 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 3.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 61: Test Choice

This is story chapter 61 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 62: Test Choice

This is story chapter 62 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 63: Test Choice

This is story chapter 63 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 64: Test Choice

This is story chapter 64 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 65: Test Choice

This is story chapter 65 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 66: Test Choice

This is story chapter 66 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 67: Test Choice

This is story chapter 67 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 68: Test Choice

This is story chapter 68 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 69: Test Choice

This is story chapter 69 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 70: Test Choice

This is story chapter 70 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 71: Test Choice

This is story chapter 71 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 72: Test Choice

This is story chapter 72 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 73: Test Choice

This is story chapter 73 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 74: Test Choice

This is story chapter 74 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 75: Test Choice

This is story chapter 75 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 76: Test Choice

This is story chapter 76 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 77: Test Choice

This is story chapter 77 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 78: Test Choice

This is story chapter 78 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 79: Test Choice

This is story chapter 79 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.

## Chapter 80: Test Choice

This is story chapter 80 of 80, used to verify EPUB import. Claire reads the letter and chooses her next step. The scene belongs to volume 4.

Fixture text includes an em dash — and a Unicode symbol 🌿 for encoding checks.
